
  # Web app conversion (Copy)

  This is a code bundle for Web app conversion (Copy). The original project is available at https://www.figma.com/design/z1IdMQQ00eQ8fn6RNYO0yA/Web-app-conversion--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  