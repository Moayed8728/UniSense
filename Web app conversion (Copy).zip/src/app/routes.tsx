import { createBrowserRouter } from "react-router";

// Auth pages
import Welcome from "./pages/auth/Welcome";
import Login from "./pages/auth/Login";
import CreateAccount from "./pages/auth/CreateAccount";
import RoleSelection from "./pages/auth/RoleSelection";
import ApplyRepresentative from "./pages/auth/ApplyRepresentative";
import ApplicationPreview from "./pages/auth/ApplicationPreview";
import PendingApproval from "./pages/auth/PendingApproval";
import RejectedApplication from "./pages/auth/RejectedApplication";
import SuspendedAccount from "./pages/auth/SuspendedAccount";

// Student pages
import StudentDashboard from "./pages/student/Dashboard";
import ComparePrograms from "./pages/student/ComparePrograms";
import SavedPrograms from "./pages/student/SavedPrograms";

// Representative pages
import RepDashboard from "./pages/rep/Dashboard";
import SubmitProgram from "./pages/rep/SubmitProgram";
import MySubmissions from "./pages/rep/MySubmissions";
import SubmissionDetails from "./pages/rep/SubmissionDetails";
import EditSubmission from "./pages/rep/EditSubmission";
import PreviewSubmission from "./pages/rep/PreviewSubmission";

// Admin pages
import AdminDashboard from "./pages/admin/Dashboard";
import ReviewSubmission from "./pages/admin/ReviewSubmission";
import SourceVerification from "./pages/admin/SourceVerification";
import ManageUniversities from "./pages/admin/ManageUniversities";
import ManageUsers from "./pages/admin/ManageUsers";
import SystemAnalytics from "./pages/admin/SystemAnalytics";
import AuditLogs from "./pages/admin/AuditLogs";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Welcome,
  },
  {
    path: "/auth",
    children: [
      { path: "login", Component: Login },
      { path: "create-account", Component: CreateAccount },
      { path: "role-selection", Component: RoleSelection },
      { path: "apply-representative", Component: ApplyRepresentative },
      { path: "application-preview", Component: ApplicationPreview },
      { path: "pending", Component: PendingApproval },
      { path: "rejected", Component: RejectedApplication },
      { path: "suspended", Component: SuspendedAccount },
    ],
  },
  {
    path: "/student",
    children: [
      { index: true, Component: StudentDashboard },
      { path: "compare", Component: ComparePrograms },
      { path: "saved", Component: SavedPrograms },
    ],
  },
  {
    path: "/rep",
    children: [
      { index: true, Component: RepDashboard },
      { path: "submit", Component: SubmitProgram },
      { path: "submissions", Component: MySubmissions },
      { path: "submissions/:id", Component: SubmissionDetails },
      { path: "submissions/:id/edit", Component: EditSubmission },
      { path: "submissions/:id/preview", Component: PreviewSubmission },
    ],
  },
  {
    path: "/admin",
    children: [
      { index: true, Component: AdminDashboard },
      { path: "review/:id", Component: ReviewSubmission },
      { path: "sources", Component: SourceVerification },
      { path: "universities", Component: ManageUniversities },
      { path: "users", Component: ManageUsers },
      { path: "analytics", Component: SystemAnalytics },
      { path: "audit", Component: AuditLogs },
    ],
  },
]);
